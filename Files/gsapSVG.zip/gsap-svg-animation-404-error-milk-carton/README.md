# GSAP: SVG Animation 404 Error  Milk Carton

A Pen created on CodePen.io. Original URL: [https://codepen.io/christinei/pen/VxpxKm](https://codepen.io/christinei/pen/VxpxKm).

Greensock (GSAP): 
SVG animation of blinking eyes and mouth movements.

Mouth animation: Using morphSVG between the two paths #mouth and #mouth-frown. Eye blink animation: Using transformOrigin and scaleY of a circle to create a blinking effect.